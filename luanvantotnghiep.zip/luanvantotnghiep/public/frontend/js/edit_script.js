const name =document.getElementById('email')
const password =document.getElementById('password')