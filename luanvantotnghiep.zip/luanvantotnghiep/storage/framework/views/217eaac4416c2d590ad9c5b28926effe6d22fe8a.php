
<?php $__env->startSection('index_content'); ?>
 <div class="login">
        <div class="wrap">
     	    <div class="rsidebar span_1_of_left">
	<!-- danh mục lọc -->
		<section  class="sky-form">
		<h4>Lọc Giá</h4>
		<div class="Loc-theo-gia">
			<form>
	                   <div id="slider-range"></div>
	                   <style type="text/css">
	                       .style-range p {
	                           float: left;
	                           width: ;
	                       }
	                   </style>
	                     <div class="style-range">
	                       <input type="text" id="amount" readonly style="border:0; color:#f6931f; font-weight:bold;">
	                      
	                   </div>
	                   <input type="hidden" name="start_price" id="start_price">
	                   <input type="hidden" name="end_price" id="end_price">

	                    <br>
	                    <div class="clearfix"></div>
	                    <button>Lọc</button>
	                    <!-- <input type="submit" name="filter_price" value="Lọc giá"> -->
	               </form>
		</div>
                <h4>Danh mục</h4>
		<div class="row row1 scroll-pane">
			<div class="col col-4">
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Quần</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Áo</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Giày</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Phụ kiện</label>
				 
			</div>
		</div>
                <h4>Category</h4>
			<div class="row row1 scroll-pane">
				<div class="col col-4">
				<?php $__currentLoopData = $all_style; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i><?php echo e($style->ten_tk); ?></label>
				 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			</div>
		<h4>Styles</h4>
		<div class="row row1 scroll-pane">
			<div class="col col-4">
				<?php $__currentLoopData = $all_color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i><?php echo e($color->ten_mau); ?></label>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		<h4>Chất lieu</h4>
		<div class="row row1 scroll-pane">
			<div class="col col-4">
				<?php $__currentLoopData = $all_material; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i><?php echo e($material->ten_cl); ?></label>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		</section>
	<!-- 	danh mục lọc -->
	   </div>
	<div class="cont span_2_of_3">
	 <div class="mens-toolbar">
       		<div class="sort">
        		<div class="sort-by">
	            <label>Sort By</label>
	            <select>
	                   <option value="">Popularity</option>
	                   <option value="">Price : High to Low</option>
	                   <option value="">Price : Low to High</option>
	            </select>
	            <a href=""><img src="<?php echo e(('public/frontend/images/arrow2.gif')); ?>" alt="" class="v-middle"></a>
        		</div>
			</div>
	        <div class="pager">   
	           <div class="limiter visible-desktop">
	            <label>Show</label>
	           	 <select>
				 <option value="" selected="selected">9</option>
			        <option value="">15</option>
			        <option value="">30</option>
		    	</select> per page        
	            </div>
	       	<ul class="dc_pagination dc_paginationA dc_paginationA06">
			    <li><a href="#" class="previous">Pages</a></li>
			    <li><a href="#">1</a></li>
			    <li><a href="#">2</a></li>
			</ul>
		   <div class="clear"></div>
	    	 </div>
	    		<div class="clear"></div>
       </div>
	<div class="box1">
	<?php foreach ($all_product as $key => $value_pro): ?>
		
	   <div class="col_1_of_single1 span_1_of_single1 show-pro"><a href="<?php echo e(URL::to('/product-details/'.$value_pro->ma_sp)); ?>">
		     	<div class="view1 view-fifth1">
		  	  	<div class="top_box">
				  	<h3 class="m_1"><?php echo e($value_pro->ma_sp); ?></h3>
				  	<p class="m_2"><?php echo e($value_pro->ten_sp); ?></p>
			         	<div class="grid_img">
					   <div class="css3"><img src="public/uploads/product/<?php echo e($value_pro->hinhanh); ?>" width="250px" height="300px" alt=""/></div>
				          <div class="mask1">
		         		<div class="info">Chi tiết</div>
		                  	</div>
		      			</div>
		  			 <div class="price"><strike><?php echo e($value_pro->gia_goc); ?></strike>&emsp;<?php echo e($value_pro->gia_sale); ?>VND</div>
			   	</div>
			</div>
			<span class="rating1">
		        <input type="radio" class="rating-input" id="rating-input-1-5" name="rating-input-1">
		        <label for="rating-input-1-5" class="rating-star1"></label>
		        <input type="radio" class="rating-input" id="rating-input-1-4" name="rating-input-1">
		        <label for="rating-input-1-4" class="rating-star1"></label>
		        <input type="radio" class="rating-input" id="rating-input-1-3" name="rating-input-1">
		        <label for="rating-input-1-3" class="rating-star1"></label>
		        <input type="radio" class="rating-input" id="rating-input-1-2" name="rating-input-1">
		        <label for="rating-input-1-2" class="rating-star"></label>
		        <input type="radio" class="rating-input" id="rating-input-1-1" name="rating-input-1">
		        <label for="rating-input-1-1" class="rating-star"></label>
		      	</span>
				 <ul class="list2">
				  <li>
				  	<img src="<?php echo e(('public/frontend/images/plus.png')); ?>" alt=""/>
				  	<ul class="icon1 sub-icon1 profile_img">
					  <li><a class="active-icon c1" href="#">Mua Ngay</a>
						<ul class="sub-icon1 list">
							<li><h3>sed diam nonummy</h3><a href=""></a></li>
							<li>
								<p>Lorem ipsum dolor sit amet,<a href="">adipiscing elit, sed diam</a></p>
							</li>
						</ul>
					  </li>
					</ul>
				  </li>
				 </ul>
		    	    <div class="clear"></div>
		    	</a>
	    </div>
	 <?php endforeach ?>
	  <div class="clear"></div>
  	</div>
	</div>
	<div class="clear"></div>
	</div>
	<script type="text/javascript">
        $(document).ready(function(){

           $( "#slider-range" ).slider({
                orientation: "horizontal",
              range: true,

              min:<?php echo e($min_price_range); ?>,
              max:<?php echo e($max_price_range); ?>,

              steps:10000,
              values: [ <?php echo e($min_price); ?>, <?php echo e($max_price); ?> ],
              slide: function( event, ui ) {
                $( "#amount" ).val( "đ" + ui.values[ 0 ] + " - đ" + ui.values[ 1 ] );


                $( "#start_price" ).val(ui.values[ 0 ]);
                $( "#end_price" ).val(ui.values[ 1 ]);
              }
            });
            $( "#amount" ).val( "đ" + $( "#slider-range" ).slider( "values", 0 ) +
              " - đ" + $( "#slider-range" ).slider( "values", 1 ) );

        }); 
</script>
</div>

		
			  
	    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\luanvantotnghiep\resources\views/pages/shop.blade.php ENDPATH**/ ?>