
<?php $__env->startSection('index_content'); ?>				
<div class="main-w3layouts wrapper">
		<div class="main-agileinfo">
			<div class="agileits-top">
				<h1 class="color">điền thông tin</h1>
					<hr>
					<hr>
				<form action="<?php echo e(URL::to('/login-us')); ?>"method="POST" >
					<?php echo csrf_field(); ?>
					<label style="color:#FFF">Email</label>
					<?php if ($errors->has('email')): ?>
                    <span style="color:red;"><?php echo e($errors->first('email')); ?></span>
                	<?php endif ?>
					<input class="text email" type="text" id="email" name="email" value="<?php echo e(old('email')); ?>">
					<label style="color:#FFF">Mật Khẩu</label>
					<?php if ($errors->has('password')): ?>
                    <span style="color:red;"><?php echo e($errors->first('password')); ?></span>
                	<?php endif ?>
					<input class="text" type="password" id="password" name="password"  value="<?php echo e(old('password')); ?>">
					<input type="submit" class="submit-dangky" value="ĐĂNG NHẬP">
				</form>
				<p><a class="dangnhapngay" href="<?php echo e(URL::to('/sign-up')); ?>">TÀI KHOẢN MỚI</a></p>
                <?php if ($errors->has('username')): ?>
                   <span style="color:red;"><?php echo e($errors->first('username')); ?></span>
                <?php endif ?>
			</div>
		</div>

		
		<ul class="colorlib-bubbles">
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
		</ul>
	</div>
<?php $__env->stopSection(); ?>      

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GraduationEssay\luanvantotnghiep\resources\views/pages/User/login_user.blade.php ENDPATH**/ ?>