@extends('layout')
@section('index_content')			
<div class=" wrapper about-shop">
			<h1 class="title" >Chính Sách và Ưu Đãi của Tiến Lên Nào</h1>
		<u><b><h3>1. Chính Sách Mua hàng</h3></b></u><br>	
		<h2>-Đối với khách hàng lẻ chỉ sắm qua website với số lượng vừa phải theo nhu cầu cá nhân</h2>
		<h2>Với việc giảm giá trên tổng giá trị đơn hàng ta có các mức sau:</h2>	
		<h4> • Tổng giá trị đơn hàng trên 500.000 vnd đến dưới 1.500.000 vnd giảm 3%.</h4>
		<h4> • Tổng giá trị đơn hàng trên 1.500.000 vnd đến 3.000.000 vnd giảm 5% . </h4>
		<h4> • Tổng giá trị đơn hàng trên 3.000.000 vnd đến 5.000.000 vnd giảm 7%.</h4>
		<h4> • Tổng giá trị đơn hàng trên 5.000.000 giảm 10%.</h4>
		<h4> • Ngoài ra khách hàng số lượng trên 20 sản phẩm sẽ được tính mức chiết khấu khách hàng sỉ và phải thành toán tiền cộc 30%.
		</h4>
		<br>
		<h2>---------------o---------------</h2>
		<br>	
		<h2>-	Đối với khách hàng sỉ là khách hàng nhu cầu mua sản phẩm với số lượng lớn sản phẩm với giá được chiết khấu.</h2>
		<h2>Với việc mau số lượng lớn sản phẩm ta có các điề kiện và ưu đãi như sau:</h2>	
		<h4> • Mỗi lô cần phải trên 20 sản phẩm có cùng một mã sản phẩm.</h4>
		<!-- <h4> • 	Khách hàng phải mua trên 3 lô hàng thì mới tính giá bán chiết khấu trên từng lô và được áp dụng hình thức chiết khấu thêm .</h4> -->
		<!-- <h4> • Nếu khách hàng chỉ có nhu cầu mua dưới 3 lô thì sẽ vẫn được tính chiết khấu từng lô nhưng sẽ không được tính chiết khấu thêm</h4> -->
		<h4> • Nếu tổng giá trị đơn hàng trên 20 triệu sẽ được chiết khấu thêm 13% trên tổng hóa đơn.</h4>
		<h4> • Nếu tổng giá trị đơn hàng sỉ trên 50 triệu sẽ được chiết khấu thêm 15% trên tổng hóa đơn.</h4>
		<h4> • Khách hàng đặt hàng đăng nhập vào hệ thống chọn phương thức thanh toán(bắt buộc) chuyển khoản 30% giá trị đơn hàng.</h4>
		<h2></h2><br>
		<u><b><h3>2. Chính Sách Đổi Trả </h3></b></u><br>
		
		<img src="{{asset('public/frontend/images/doi tra.jpg')}}">
		<h4></h4><br>
		<u><b><h3>3. Chính Sách Bảo Hành</h3></b></u><br>
		<img src="{{asset('public/frontend/images/bao hanh.jpg')}}">><h4></h4><br>

		<h4>Địa chỉ dễ dàng tìm kiếm và thuận tiện</h4><br>
		<div id="gmap" class="contact-map">
                        <iframe width="1150px" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.726512256121!2d106.72569841386729!3d10.755548292335689!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752588a274486d%3A0x827ef7af424cca79!2zODcsIDEwIEzGsHUgVHLhu41uZyBMxrAsIFTDom4gVGh14bqtbiDEkMO0bmcsIFF14bqtbiA3LCBI4buTIENow60gTWluaCwgVmnhu4d0IE5hbQ!5e0!3m2!1svi!2s!4v1575211406130!5m2!1svi!2s" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                    </div>

		<ul class="colorlib-bubbles">
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
		</ul>
	</div>
@endsection