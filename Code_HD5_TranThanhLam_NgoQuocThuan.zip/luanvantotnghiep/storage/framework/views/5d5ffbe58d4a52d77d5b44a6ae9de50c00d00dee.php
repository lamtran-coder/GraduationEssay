
<?php $__env->startSection('index_content'); ?>
<div class="single">
         <div class="wrap">
     	    <div class="rsidebar span_1_of_left">
			  <!-- danh mục lọc -->
			    <section  class="sky-form">
			                <h4>Danh mục</h4>
			    <div class="row row1 scroll-pane">
			      <div class="col col-4">
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Quần</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Áo</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Giày</label>
				<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Phụ kiện</label>
				 
			</div>
			    </div>
			                <h4>Thiết kế</h4>
			      <div class="row row1 scroll-pane">
			        <div class="col col-4">
			        <?php $__currentLoopData = $all_style; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			        <label class="checkbox"><input type="checkbox" name="checkbox"><i></i><?php echo e($style->ten_tk); ?></label>
			         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			      </div>
			      </div>
			    <h4>Màu sắc</h4>
			    <div class="row row1 scroll-pane">
			      <div class="col col-4">
			        <?php $__currentLoopData = $all_color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			        <label class="checkbox"><input type="checkbox" name="checkbox"><i></i><?php echo e($color->ten_mau); ?></label>
			        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			      </div>
			    </div>
			    <h4>Chất lieu</h4>
			    <div class="row row1 scroll-pane">
			      <div class="col col-4">
			        <?php $__currentLoopData = $all_material; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			        <label class="checkbox"><input type="checkbox" name="checkbox"><i></i><?php echo e($material->ten_cl); ?></label>
			        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			      </div>
			    </div>
			    </section>
			    <div class="clear"></div>
			  <!--  danh mục lọc -->
			     </div>

<?php foreach ($details_product as $key => $value_det): ?>
	<div class="cont span_2_of_3">
		<div class="labout span_1_of_a1">
			<!-- start product_slider -->
	     <ul id="etalage">
							
				<a href="optionallink.html">		
				
					<img class="etalage_thumb_image" src="<?php echo e(asset('public/frontend/images/hinh140x175.jpg')); ?>"  width="250px" height="300px" />
					
					<img class="etalage_source_image" src="<?php echo e(asset('public/frontend/images/hinh140x175.jpg')); ?>" width="250px" height="300px" />
				</a>	
					<?php foreach ($all_img as $key => $value_img): ?>
						<?php if ($value_det->ma_sp==$value_img->ma_sp): ?>
				<li>
					<img class="etalage_thumb_image" src="<?php echo e(URL::to('public/uploads/product/'.$value_img->hinhanh)); ?>" alt="">
					<img class="etalage_source_image" src="<?php echo e(URL::to('public/uploads/product/'.$value_img->hinhanh)); ?>" alt="">
				</li>
						<?php endif ?>		
					<?php endforeach ?>
			</ul>	
			<!-- end product_slider -->
		</div>

		<div class="cont1 span_2_of_a1 ">
			<h3 class="m_3"><?php echo e($value_det->ma_sp); ?></h3>
			
			<div class="price_single">
						  <span class="reducedfrom">
						  	<?php echo number_format($value_det->gia_goc);  ?>
						  </span>
						  <span class="actual">
						  	<?php echo number_format($value_det->gia_sale).' VND';  ?>	
						  </span>
						</div>
			<ul class="options">
				<h4 class="m_9">CHỌN KÍCH CỠ</h4>
	
					<table>
						<tbody>
							<?php $__currentLoopData = $all_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($value_detail->ma_sp==$value_det->ma_sp): ?>
							<tr style="height: 30px">
								<td style="width: 150px"><?php echo e($value_detail->ma_size); ?>-<?php echo e($value_detail->ten_mau); ?></td>
								<td style="width: 60px"><?php echo e($value_detail->so_lg); ?>SP</td>
								<td style="width: 60px">
									<form action="<?php echo e(URL::to('/save-cart')); ?>" method="POST">
									   <?php echo csrf_field(); ?>	
									   <input type="hidden" name="masp_hidden" min="1" value="<?php echo e($value_det->ma_sp); ?>">
									   <input type="hidden" name="mau_hidden" min="1" value="<?php echo e($value_detail->ten_mau); ?>">
									   <input type="hidden" name="size_hidden" min="1" value="<?php echo e($value_detail->ma_size); ?>">
										<button class="button-mua">Mua</button>	
									</form>
								</td>
							</tr>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 	
						</tbody>
					</table>
				<div class="clear"></div>
			</ul>
			<ul>
				
			</ul>
			<ul class="add-to-links">
			   <li><img src="<?php echo e(asset('public/frontend/images/wish.png')); ?>" alt=""/><a href="#">Thêm vào danh sách yêu thích</a></li>
			</ul>
			
            <div class="social_single">	
			   <ul>	
				  <li class="fb"><a href="#"><span> </span></a></li>
				  <li class="tw"><a href="#"><span> </span></a></li>
				  <li class="g_plus"><a href="#"><span> </span></a></li>
				  <li class="rss"><a href="#"><span> </span></a></li>		
			   </ul>
		    </div>
			<p class="m_desc"><?php echo e($value_det->mo_ta); ?></p>
		</div>
		<div class="clear"></div>
     
     
         <ul id="flexiselDemo3">
			<?php $__currentLoopData = $related_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     	 	<?php if (($ma_dm = '$related->ma_dm')&&($related->goc_nhin==0)): ?>	
     	 	<li><a href="<?php echo e(URL::to('/product-details/'.$related->ma_sp)); ?>">
     	 			<img src="<?php echo e(URL::to('public/uploads/product/'.$related->hinhanh)); ?>" width="125px" height="150px" />
     	 			<div class="grid-flex">
     	 				<a href="<?php echo e(URL::to('/product-details/'.$related->ma_sp)); ?>"><?php echo e($related->ten_sp); ?></a>
     	 				<p><?php echo number_format($related->gia_goc).' VND'; ?></p>
     	 			</div>
     	 		</a>	
     	 	</li>
     	 	
			 <?php endif ?>
			 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		 </ul>
	    <script type="text/javascript">
		 $(window).load(function() {
			$("#flexiselDemo1").flexisel();
			$("#flexiselDemo2").flexisel({
				enableResponsiveBreakpoints: true,
		    	responsiveBreakpoints: { 
		    		portrait: { 
		    			changePoint:480,
		    			visibleItems: 1
		    		}, 
		    		landscape: { 
		    			changePoint:640,
		    			visibleItems: 2
		    		},
		    		tablet: { 
		    			changePoint:768,
		    			visibleItems: 3
		    		}
		    	}
		    });
		
			$("#flexiselDemo3").flexisel({
				visibleItems: 5,
				animationSpeed: 1000,
				autoPlay: true,
				autoPlaySpeed: 3000,    		
				pauseOnHover: true,
				enableResponsiveBreakpoints: true,
		    	responsiveBreakpoints: { 
		    		portrait: { 
		    			changePoint:480,
		    			visibleItems: 1
		    		}, 
		    		landscape: { 
		    			changePoint:640,
		    			visibleItems: 2
		    		},
		    		tablet: { 
		    			changePoint:768,
		    			visibleItems: 3
		    		}
		    	}
		    });
		    
		});
	</script>
	<script type="text/javascript" src="<?php echo e(asset('public/frontend/js/jquery.flexisel.js')); ?>"></script>
     	<div class="comment-card">
     	<h3>Bình Luận<i class="fa fa-comment"></i></h3>
     	<div class="comment-content">
     		<form>
     			<?php echo csrf_field(); ?>				
     			<input type="hidden" name="comment_product_id" class="comment_product_id" value="<?php echo e($value_det->ma_sp); ?>">

     				<div id="comment_show"></div>
	     	</form>    	

     	</div>
     	<?php $username=Session::get('username');?>
     	<?php if ($username!=null): ?>
     		
		<form action="#">
			<?php echo csrf_field(); ?>
     	<div class="comment-new">
     		<div>
     			<label><?php echo $username; ?></label>
     			<input style="color:black" type="hidden"   class="comment_name" value="<?php echo $username; ?>" >
     			
     			<!-- đánh giá -->
     			<ul class="list-inline" style="display: -webkit-box;" title="Average Raiting">
     				<?php 
					for ($i=1; $i <=5 ; $i++) { 
					?>	
     				<li title="Đánh giá sao" 
     				id=""
     				data-index=""
     				data-product=""
     				data-rating=""
     				class="raiting"
     				style="cursor: pointer; color: #CCC;font-size: 30px;" 
     				>&#9733;	
     				</li>
     				<?php }?>
     			</ul>
     			<!-- đánh giá --> 
     			<textarea class="style_comment comment_content"></textarea>
     			
     		</div>
     		<button><i class="fa fa-upload send-comment"></i></button>
     		<div id="notify_comment"></div>
     	</div>
     	</form>
     	<?php else: ?>
     		<div  class="comment-new"><a href="{{}}">Đăng Nhập Để Bình Luận</a></div>
     	<?php endif ?>
     </div>				
     </div>
     
<?php endforeach ?>
     <div class="clear"></div>
	 </div>
     </div>
	  
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\luanvantotnghiep\resources\views/pages/single.blade.php ENDPATH**/ ?>