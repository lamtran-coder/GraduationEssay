
<?php $__env->startSection('admin_content'); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      Danh sách khách hàng
    </div>
    <div class="row w3-res-tb">
        <div class="col-sm-4">
        <form >
          <div class="input-group">
            <input type="text" class="input-sm form-control" name="keywords_search" placeholder="nhập từ khóa">
            <span class="input-group-btn">
              <button class="btn btn-sm btn-default" type="button">Tìm</button>
            </span>
          </div>
        </form>
        </div>
      <div class="col-sm-4">
        <?php if (isset($_GET['keywords_search'])): ?>
            <span style="color:red;font-size: 20px;padding-left: 30px;font-weight: bolder;">Từ Khóa: <?php echo $result=$_GET['keywords_search']; ?></span>
        <?php endif ?>
      </div>
    </div>
    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
          
            <th>Tên khách hàng</th>
            <th>Email</th>
            <th>So điện thoại</th>
            <th>Địa chỉ</th>
            <th>Tiền Đã Tiêu</th>
            <th>Người Nhận</th>
          </tr>
        </thead>
        <tbody  style="text-transform: none;">
          <?php foreach ($use_id as $key => $value_user): ?>
            
         
          <tr>
      
           
            <td><span class="text-ellipsis"><?php echo e($value_user->ten_nd); ?></span></td>
            <td><span class="text-ellipsis"><?php echo e($value_user->email); ?></span></td>
            <td><span class="text-ellipsis"><?php echo e($value_user->sodt); ?></span></td>
            <td><span class="text-ellipsis" id="AnHien<?php echo e($key); ?>"><?php echo e($value_user->diachi); ?></span>
                 <script>
                  $(document).ready(function() {
                    $("#AnHien<?php echo e($key); ?>").hide();
                      $("#button<?php echo e($key); ?>").click(function(){
                          $("#AnHien<?php echo e($key); ?>").toggle();
                      });
                  });
                  </script>
                  <button id="button<?php echo e($key); ?>">...</button>
            </td>
            <td><span class="text-ellipsis" style="color:red;font-size: 20px;">
                <?php echo number_format($value_user->sodatieu).' vnđ'; ?>
            </span></td>
            <td><a href="<?php echo e(URL::to('/dia-chi-nhan/'.$value_user->email)); ?>"><i class="fa fa-search" style="font-size: 30px;"></i></a></td>
          </tr>
          <?php endforeach ?>
         
          
        </tbody>
      </table>
    </div>
    <footer class="panel-footer">
      <div class="row">
        
        <div class="col-sm-5 text-center">
  
        </div>
        <div class="col-sm-7 text-right text-center-xs">                
          <ul class="pagination pagination-sm m-t-none m-b-none">
            <?php echo e($use_id->appends(Request::all())->links()); ?>

          </ul>
        </div>
      </div>
    </footer>
  </div>
</div>
</section>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GraduationEssay\pro\luanvantotnghiep\resources\views/admin/Customer/customer_all.blade.php ENDPATH**/ ?>