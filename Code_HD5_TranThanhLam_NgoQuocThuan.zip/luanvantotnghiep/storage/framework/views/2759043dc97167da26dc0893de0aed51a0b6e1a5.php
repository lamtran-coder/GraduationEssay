
<?php $__env->startSection('admin_content'); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      liệt kê danh mục
    </div>
     <div class="row w3-res-tb">
      <div class="col-sm-4">
      </div>
       <div class="row w3-res-tb">
      
       <form action="<?php echo e(URL::to('/search-cate-ad')); ?>" method="post">
          <?php echo csrf_field(); ?>
      <div class="col-sm-3">
        <div class="input-group">
          <input type="text" class="input-sm form-control"name="keywords_submit" placeholder="nhập từ khóa" value="">
          <span class="input-group-btn">
            <button class="btn btn-sm btn-default" type="button">TÌM</button>
          </span>
         </div>
        </div>
      </form>
        
      </div>
    </div>
    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <th style="width:20px;">
              <label class="i-checks m-b-none">
                <input type="checkbox"><i></i>
              </label>
            </th>
             <th>Tên slide</th>
            <th>Hình ảnh</th>
            <th>Mô tả</th>
            <th>Tình trạng</th>
            <th style="width:30px;"></th>
          </tr>
        </thead>
       <tbody>
          <?php $__currentLoopData = $all_slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><label class="i-checks m-b-none"><input type="checkbox" name="post[]"><i></i></label></td>
            <td><?php echo e($slide->slider_name); ?></td>
            <td><img src="public/uploads/slider/<?php echo e($slide->slider_image); ?>" height="300" width="500"></td>
            <td><?php echo e($slide->slider_desc); ?></td>
            <td><span class="text-ellipsis">
              <?php
               if($slide->slider_status==1){
                ?>
                <a href="<?php echo e(URL::to('/unactive-slide/'.$slide->slider_id)); ?>"><span class="fa-thumb-styling fa fa-thumbs-up" 
                  style="font-size: 25px;color: green;"></span></a>
                <?php
                 }else{
                ?>  
                 <a href="<?php echo e(URL::to('/active-slide/'.$slide->slider_id)); ?>"><span class="fa-thumb-styling fa fa-thumbs-down"
                   style="font-size: 25px;color: red;"></span></a>
                <?php
               }
              ?>
            </span></td>
            <td>
             
              <a onclick="return confirm('Bạn có chắc là muốn xóa slide này ko?')" href="<?php echo e(URL::to('/delete-slide/'.$slide->slider_id)); ?>" class="active styling-edit" ui-toggle-class="">
                <i class="fa fa-times text-danger text"></i>
              </a>

            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <footer class="panel-footer">
      <div class="row">
        <div class="col-sm-7 text-right text-center-xs">                
          <ul class="pagination pagination-sm m-t-none m-b-none">
            <?php echo e($all_slide->links()); ?>

          </ul>
        </div>
      </div>
    </footer>
  </div>
</div>
</section>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GraduationEssay\luanvantotnghiep\resources\views/admin/list_slider.blade.php ENDPATH**/ ?>