
<?php $__env->startSection('index_content'); ?>
    <div class="register_account">
          	<div class="wrap">
    	      <h4 class="title">Tạo tài khoản  </h4>
    		   <form action=" <?php echo e(URL::to('/add-user')); ?>"method="POST">
    		   	<?php echo csrf_field(); ?>
    			 <div class="col_1_of_2 span_1_of_2">
		   			 
		    			
		    		<input type="text" name="email" placeholder="email">
		    		<input type="text" name="matkhau" placeholder="matkhau">
		    			<button class="grey">Đăng ký</button>
		    			 <p class="terms">Tạo tài khoản nhanh để sử dụng trang </a>.</p>
		        
		    	 </div>
		    	  
		          <div class="clear"></div>
		        
		    </form>
    	  </div> 
        </div>
<?php $__env->stopSection(); ?>     

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\luanvantotnghiep\resources\views/pages/sign_up.blade.php ENDPATH**/ ?>